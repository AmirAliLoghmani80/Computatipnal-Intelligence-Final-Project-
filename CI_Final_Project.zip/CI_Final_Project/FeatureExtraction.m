%%
% Phase 1 feature extraction
a = load('Project_data.mat');
temp = a.TrainData; 
v = calculate_variance(temp);
av_amp = calculate_average_amplitude(temp);
median_freq = calculate_median_frequency(temp);
mean_freq = calculate_mean_frequency(temp);
band_power = calculate_bandpower(temp);
max_freq = getMaxFrequency(temp);
delta = calculatePSR(temp, "Delta");
theta = calculatePSR(temp, "Theta");
alpha = calculatePSR(temp, "Alpha");
low_range_beta = calculatePSR(temp, "Low-Range-Beta");
mid_range_beta = calculatePSR(temp, "Mid-Range-Beta");
high_range_beta = calculatePSR(temp, "High-Range-Beta");
gamma = calculatePSR(temp, "Gamma");

TrainLabel = a.TrainLabels;
f_v = fisherScore(v,TrainLabel);
f_av = fisherScore(av_amp,TrainLabel);
f_median_freq = fisherScore(median_freq,TrainLabel);
f_mean_freq = fisherScore(mean_freq,TrainLabel);
f_band_power = fisherScore(band_power,TrainLabel);
f_max_freq = fisherScore(max_freq,TrainLabel);
f_delta = fisherScore(delta,TrainLabel);
f_theta = fisherScore(theta,TrainLabel);
f_alpha = fisherScore(alpha,TrainLabel);
f_low_range_beta = fisherScore(low_range_beta,TrainLabel);
f_mid_range_beta = fisherScore(mid_range_beta,TrainLabel);
f_high_range_beta = fisherScore(high_range_beta,TrainLabel);
f_gamma = fisherScore(gamma,TrainLabel);

features = f_v;
features = [features; f_av];
features = [features; f_median_freq];
features = [features; f_mean_freq];
features = [features; f_band_power];
features = [features; f_max_freq];
features = [features; f_delta];
features = [features; f_theta];
features = [features; f_alpha];
features = [features; f_low_range_beta];
features = [features; f_mid_range_beta];
features = [features; f_high_range_beta];
features = [features; f_gamma];

feat_names = bestFeatureForChannel(features);

feat_ex = featureExtraction(feat_names,v,av_amp,mean_freq,median_freq,max_freq,delta,alpha,low_range_beta,mid_range_beta,high_range_beta,gamma,theta,band_power);

[best_feats_name, best_feats_channel] = maxFishersTotal(features,59);
feat_ex_total = feature_Extraction_Total(59,best_feats_name,best_feats_channel,v,av_amp,mean_freq,median_freq,max_freq,delta,alpha,low_range_beta,mid_range_beta,high_range_beta,gamma,theta,band_power);


%%
% Phase 2 feature extraction

[best_feats_name_ga, best_feats_channel_ga] = maxFishersTotal(features,200);
feat_ex_total_ga = feature_Extraction_Total(200,best_feats_name_ga,best_feats_channel_ga,v,av_amp,mean_freq,median_freq,max_freq,delta,alpha,low_range_beta,mid_range_beta,high_range_beta,gamma,theta,band_power);

data = load('Project_data.mat');
TrainLabel = data.TrainLabels;
AllFeatures = feat_ex_total_ga;

populationSize = 50;
numberOfGenerations = 100;
chromosomeLength = 50;
geneRange = [1, 200];


population = zeros(populationSize, chromosomeLength);

for i = 1:populationSize
    uniqueGenes = randperm(diff(geneRange) + 1, chromosomeLength) + geneRange(1) - 1;
    population(i, :) = uniqueGenes;
end

for generation = 1:numberOfGenerations
    fitness_ = arrayfun(@(i) fitness(getChromosomeFeatures(AllFeatures,population(i, :)),TrainLabel), 1:populationSize);

    [~, idx] = sort(fitness_, 'descend');
    selectedParents = population(idx(1:ceil(0.1*populationSize)), :);
    
    crossoverPoints = randi([1, chromosomeLength - 1], floor(size(selectedParents, 1)/2), 1);
    for i = 1:2:size(selectedParents, 1)-1
        crossoverPoint = crossoverPoints((i+1)/2);
        temp = selectedParents(i, crossoverPoint+1:end);
        selectedParents(i, crossoverPoint+1:end) = selectedParents(i+1, crossoverPoint+1:end);
        selectedParents(i+1, crossoverPoint+1:end) = temp;
    end
    
    mutationRange = 50; 
    mutationMask = randn(size(selectedParents)) * mutationRange; 

    selectedParents = selectedParents + floor(mutationMask);

    selectedParents(selectedParents < 1) = 1;
    selectedParents(selectedParents > 200) = 200;

    newPopulation = [population; selectedParents];
    
    fitnessValues = zeros(size(newPopulation, 1), 1);

for i = 1:size(newPopulation, 1)
    chromosome = newPopulation(i, :);
    features = getChromosomeFeatures(AllFeatures, chromosome);
    fitnessValues(i) = fitness(features, TrainLabel);
end

[~, idx] = sort(fitnessValues, 'descend');

    
population = newPopulation(idx(1:populationSize), :);
    bestIndividual = population(1, :);
    bestValue = fitness(getChromosomeFeatures(AllFeatures,bestIndividual),TrainLabel);
end

feat_ga_final = getChromosomeFeatures(AllFeatures,bestIndividual);
feat_ga_final = normalize(feat_ga_final);
%%
% Replace this with your actual fitness function
function output = fitness(chromosomeFeatures,TrainLabel)

N1 = length(find(TrainLabel == 1));
N2 = length(find(TrainLabel == -1));
index1 = find(TrainLabel == 1);
index0 = find(TrainLabel == -1);
% indexes = find(seletcting_vector == 1);
chromosomeFeatures = chromosomeFeatures';    
mu1 = sum(chromosomeFeatures(index1, :)) / N1;
mu2 = sum(chromosomeFeatures(index0, :)) / N2;
mu0 = sum(chromosomeFeatures) / (N1 + N2);

s1 = zeros(50);
for i = index1
    s1 = s1 + transpose(chromosomeFeatures(i, :) - mu1) * (chromosomeFeatures(i, :) - mu1);
end
s1 = s1 / N1;

s2 = zeros(50);
for i = index0
    s2 = s2 + transpose(chromosomeFeatures(i, :) - mu2) * (chromosomeFeatures(i, :) - mu2);
end
s2 = s2 / N2;

S_w = s1 + s2;
S_b = transpose(mu1 - mu0) * (mu1 - mu0) + transpose(mu2 - mu0) * (mu2 - mu0);

output = trace(S_b) / trace(S_w);
end

function output = getChromosomeFeatures(AllFeatures,ChromosomeFeatures)
    selectedRows = zeros(50, 550);
    for i = 1:50
        selectedRows(i, :) = AllFeatures(ChromosomeFeatures(i), :);
    end
    output = selectedRows;
end

function output = calculate_variance(input_matrix)
    v = var(input_matrix, 0, 2);
    output = squeeze(v);
end 
function result = calculate_average_amplitude(data)
    % Calculate average amplitude along the second dimension (dimension 2)
    amplitudes = sqrt(sum(abs(data).^2, 2));
    t = mean(amplitudes, 2);
    result = squeeze(t);
end

% function result = calculate_amplitude_histogram(data)
%     % Calculate amplitude histogram along the second dimension (dimension 2)
%     num_bins = 50;
%     amplitudes = sqrt(sum(abs(data).^2, 2));
%     result = zeros(size(amplitudes, 1), num_bins);
% 
%     for i = 1:size(amplitudes, 1)
%         result(i, :) = histcounts(amplitudes(i, :), num_bins);
%     end
% end
function result = calculate_median_frequency(data)
medium_freq = zeros(59,size(data,3));
for i=1:59
    
    % Loading data of different channels
    temp = data(i, :, :);
    temp = squeeze(temp);
    
    % Calculating Entropy for each trial
    for j = 1:size(data,3)
        medium_freq(i, j) = medfreq (temp(j, :));
    end
    result = medium_freq;
end
end
function result = calculate_mean_frequency(data)
mean_freq = zeros(59,size(data,3));
for i=1:59
    
    % Loading data of different channels
    temp = data(i, :, :);
    temp = squeeze(temp);
    
    % Calculating Entropy for each trial
    for j = 1:size(data,3)
        mean_freq(i, j) = meanfreq (temp(j, :));
    end
    result = mean_freq;
end
end

function result = calculate_bandpower(data)
band_power = zeros(59,size(data,3));
for i=1:59
    
    % Loading data of different channels
    temp = data(i, :, :);
    temp = squeeze(temp);
    
    % Calculating Entropy for each trial
    for j = 1:size(data,3)
        band_power(i, j) = bandpower(temp(j, :));
    end
    result = band_power;
end
end

function result = calculate_psd(data)
psd = zeros(59,size(data,3));
for i=1:59
    
    % Loading data of different channels
    temp = data(i, :, :);
    temp = squeeze(temp);
    
    % Calculating Entropy for each trial
    for j = 1:size(data,3)
        psd(i, j) = pwelch(temp(j, :));
    end
    result = psd;
end
end
function maxFrequency = getMaxFrequency(data)
    fs = 1000;
    max_f = zeros(59,size(data,3));
    for i=1:59
        temp = data(i, :, :);
        temp = squeeze(temp);
        for j = 1:size(data,3)
            signal = temp(j, :);
            N = length(signal);
            fft_result = fft(signal);
            frequencies = fs * (0:(N/2)) / N;
            amplitudes = abs(fft_result(1:N/2+1));
            [~, maxIndex] = max(amplitudes);
            max_f(i, j) = mean(frequencies(maxIndex));        
        end
    end
    maxFrequency = max_f;
end



function output = calculatePSR(data, Type)
    fs = 1000;
    frequencyRange = frequncy_range(Type);
    psr = zeros(59,size(data,3));
    for i=1:59
        temp = data(i, :, :);
        temp = squeeze(temp);
        for j = 1:size(data,3)
            signal = temp(j, :);
%             N = length(signal);
%             fft_result = fft(signal);
%             frequencies = fs * (0:(N/2)) / N;
%             amplitudes = abs(fft_result(1:N/2+1));
%             [~, maxIndex] = max(amplitudes);
%             max_f(i, j) = mean(frequencies(maxIndex)); 
            [pxx, freq] = pwelch(signal, [], [], [], fs);
            rangeIndices = freq >= frequencyRange(1) & freq <= frequencyRange(2);
            if nnz(rangeIndices) == 1
            nonzeroIndex = find(rangeIndices);
            if nonzeroIndex > 1
            rangeIndices(nonzeroIndex - 1) = 1;
            end
            if nonzeroIndex < length(rangeIndices)
            rangeIndices(nonzeroIndex + 1) = 1;
            end
            end
            powerInRange = trapz(freq(rangeIndices), pxx(rangeIndices));
            totalPower = trapz(freq, pxx);
            psr(i, j) = powerInRange / totalPower;
        end
    end
    output = psr;

end

function output = frequncy_range(a)
    
    if strcmp(a, "Delta")
        output(1) = 0.1;
        output(2) = 4;
    end
    if strcmp(a, "Theta")
        output(1) = 4;
        output(2) = 8;
    end
    if strcmp(a, "Alpha")
        output(1) = 8;
        output(2) = 12;
    end
    if strcmp(a, "Low-Range-Beta")
        output(1) = 12;
        output(2) = 16;
    end
    if strcmp(a, "Mid-Range-Beta")
        output(1) = 16;
        output(2) = 21;
    end
    if strcmp(a, "High-Range-Beta")
        output(1) = 21;
        output(2) = 30;
    end
    if strcmp(a, "Gamma")
        output(1) = 30;
        output(2) = 100;
    end
end
function frequencyRange = getFrequencyRange(signal)
    fs = 1000;
    N = length(signal);
    fft_result = fft(signal);
    frequencyRange = (0:N-1) * (fs/N);
    frequencyRange = frequencyRange(1:N/2);
end
function output = fisherScore(feature,TrainLabel)
    score = zeros(1,59);
 for i=1:59
    index1 = find(TrainLabel == 1);
    index0 = find(TrainLabel == -1);
    mu0 = sum(feature(i, :)) / length(feature);
    mu1 = sum(feature(i, index1)) / length(index1);
    mu2 = sum(feature(i, index0)) / length(index0);
    var1 = var(feature(i, index1));
    var2 = var(feature(i, index0));
    score(i) = ((mu0 - mu1)^2 + (mu0 - mu2)^2) / (var1 + var2); 
 end
 output = score;

end

function output = bestFeatureForChannel(features)
names = strings(1, 59);
for i = 1:59
    temp = find(features(:, i) == max(features(:, i)));
    names(i) = feature_selection(temp);
%     disp(['The best property for channel ', num2str(i), ' is ', num2feature(temp(i)), ', The fisher score is equal to ', num2str(max(J_mat(:, i)))]);
end
output = names ;



end

function feature_name = feature_selection(a)
    if (a == 1)
        feature_name = 'Variance';
    end
    if (a == 2)
        feature_name = 'Average';
    end
    if (a == 3)
        feature_name = 'Median Freq';
    end
    if (a == 4)
        feature_name = 'Mean Freq';
    end
    if (a == 5)
        feature_name = 'Band Power';
    end
    if (a == 6)
        feature_name = 'Max Freq';
    end
    if (a == 7)
        feature_name = 'Delta Wave';
    end
    if (a == 8)
        feature_name = 'Theta Wave';
    end
    if (a == 9)
        feature_name = 'Alpha Wave';
    end
    if (a == 10)
        feature_name = 'Low Range Beta Wave';
    end
    if (a == 11)
        feature_name = 'Mid Range Beta Wave';
    end
    if (a == 12)
        feature_name = 'High Range Beta Wave';
    end
    if (a == 13)
        feature_name = 'Gamma Wave';
    end
end

function output = featureExtraction(best_feats,var,av,mean_freq,med_freq,max_freq,delta,alpha,low_beta,mid_beta,high_beta,gamma,theta,bp)
feats = zeros(59,550);
for i=1:59
        if strcmp(best_feats(i), "Variance")
        feats(i,:) = var(i,:);
        end
        if  strcmp(best_feats(i), "Average")
        feats(i,:) = av(i,:);
        end
        if  strcmp(best_feats(i), "Median Freq")
        feats(i,:) = med_freq(i,:);
        end
        if  strcmp(best_feats(i), "Mean Freq")
        feats(i,:) = mean_freq(i,:);
        end
        if  strcmp(best_feats(i), "Max Freq")
        feats(i,:) = max_freq(i,:);
        end
        if  strcmp(best_feats(i), "Band Power")
        feats(i,:) = av(i,:);
        end
        if  strcmp(best_feats(i), "Delta Wave")
        feats(i,:) = delta(i,:);
        end
        if  strcmp(best_feats(i), "Alpha Wave")
        feats(i,:) = alpha(i,:);
        end
        if  strcmp(best_feats(i), "Low Range Beta Wave")
        feats(i,:) = low_beta(i,:);
        end
        if  strcmp(best_feats(i), "Mid Range Beta Wave")
        feats(i,:) = mid_beta(i,:);
        end
        if  strcmp(best_feats(i), "High Range Beta Wave")
        feats(i,:) = high_beta(i,:);
        end
        if  strcmp(best_feats(i), "Gamma Wave")
        feats(i,:) = gamma(i,:);
        end
        if  strcmp(best_feats(i), "Theta Wave")
        feats(i,:) = theta(i,:);
        end
end
 output = feats;
end


function [output_feat_name, output_channel_num] = maxFishersTotal(features,n)
[sortedValues, sortedIndices] = sort(features(:), 'descend');
[feat_idx, channel_num] = ind2sub(size(features), sortedIndices(1:n));
names = strings(1, n);

for i=1:n
        names(i) = feature_selection(feat_idx(i));
end
output_feat_name = names;
output_channel_num = channel_num;
end



function output = feature_Extraction_Total(n,best_feats_name,best_feats_channel,var,av,mean_freq,med_freq,max_freq,delta,alpha,low_beta,mid_beta,high_beta,gamma,theta,bp)
feats = zeros(n,550);
for i=1:n
        temp = best_feats_channel(i);
        if strcmp(best_feats_name(i), "Variance")
        
        feats(i,:) = var(temp,:);
        end
        if  strcmp(best_feats_name(i), "Average")
        feats(i,:) = av(temp,:);
        end
        if  strcmp(best_feats_name(i), "Median Freq")
        feats(i,:) = med_freq(temp,:);
        end
        if  strcmp(best_feats_name(i), "Mean Freq")
        feats(i,:) = mean_freq(temp,:);
        end
        if  strcmp(best_feats_name(i), "Max Freq")
        feats(i,:) = max_freq(temp,:);
        end
        if  strcmp(best_feats_name(i), "Band Power")
        feats(i,:) = av(temp,:);
        end
        if  strcmp(best_feats_name(i), "Delta Wave")
        feats(i,:) = delta(temp,:);
        end
        if  strcmp(best_feats_name(i), "Alpha Wave")
        feats(i,:) = alpha(temp,:);
        end
        if  strcmp(best_feats_name(i), "Low Range Beta Wave")
        feats(i,:) = low_beta(temp,:);
        end
        if  strcmp(best_feats_name(i), "Mid Range Beta Wave")
        feats(i,:) = mid_beta(temp,:);
        end
        if  strcmp(best_feats_name(i), "High Range Beta Wave")
        feats(i,:) = high_beta(temp,:);
        end
        if  strcmp(best_feats_name(i), "Gamma Wave")
        feats(i,:) = gamma(temp,:);
        end
        if  strcmp(best_feats_name(i), "Theta Wave")
        feats(i,:) = theta(temp,:);
        end
end
 output = feats;
end